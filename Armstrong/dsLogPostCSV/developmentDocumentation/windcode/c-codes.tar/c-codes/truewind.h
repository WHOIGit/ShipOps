#define pi acos(-1.)

void truewind(int num, int sel, float crse[], float cspd[], float 
    wdir[], float zlr, float hd[], float adir[], float wspd[], float 
    wmis[4], float tdir[], float tspd[], int nw, int nwam, int nwpm, 
    int nwf);

void full(int num, float crse[], float cspd[], float wdir[], float
    zlr, float hd[], float adir[], float wspd[], float tdir[], 
    float tspd[]);

void missing_values(int num, float crse[], float cspd[], float wdir[], 
    float hd[], float wspd[], float tdir[], float tspd[],float wmis[]);

void truerr(int num, float crse[], float cspd[], float hd[], 
    float wdir[], float wspd[], float wmis[], int nw, int nwpm, 
    int nwam, int nwf);
